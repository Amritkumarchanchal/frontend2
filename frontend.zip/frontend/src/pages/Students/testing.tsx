import JsonFileEditor from '@/components/AdminComponents/QuestionGeneration/JsonFileEditor'
import React from 'react'

const testing = () => {
  return (
    <div><JsonFileEditor /></div>
  )
}

export default testing