import { QuestionTabSwitcher } from '@/components/ui/QuestionTabSwitcher'

const QuestionCreationDashboard = () => {
  return (
    <div>
      <QuestionTabSwitcher />
    </div>
  )
}

export default QuestionCreationDashboard
