import * as dotenv from 'dotenv';

dotenv.config();
const LMS_URL=process.env.LMSE_URL;
export default LMS_URL;

