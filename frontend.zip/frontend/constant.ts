const API_URL = import.meta.env.VITE_LMS_ENGINE_URL
const ACTIVITY_URL = import.meta.env.VITE_ACTIVITY_ENGINE_URL

export default API_URL
export { ACTIVITY_URL }
